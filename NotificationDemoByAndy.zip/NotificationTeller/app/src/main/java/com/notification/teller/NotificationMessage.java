package com.notification.teller;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

public class NotificationMessage extends LitePalSupport implements Serializable {

    private int id;
    private String postTime;
    private String systemTime;
    private String appName;
    private String appPkg;
    private String title;
    private String content;
    private int priority;
    private int batteryLevel;
    private int isCharging;
    private String screenStatus;
    private String ringMode;
    private String location;
    private double latitude;
    private double longitude;
    private String connectionType;
    private String operation;//接收or移除

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPostTime() {
        return postTime;
    }

    public void setPostTime(String postTime) {
        this.postTime = postTime;
    }

    public String getSystemTime() {
        return systemTime;
    }

    public void setSystemTime(String systemTime) {
        this.systemTime = systemTime;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppPkg() {
        return appPkg;
    }

    public void setAppPkg(String appPkg) {
        this.appPkg = appPkg;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getBatteryLevel() {
        return batteryLevel;
    }

    public void setBatteryLevel(int batteryLevel) {
        this.batteryLevel = batteryLevel;
    }

    public int isCharging() {
        return isCharging;
    }

    public void setCharging(int charging) {
        isCharging = charging;
    }

    public String getScreenStatus() {
        return screenStatus;
    }

    public void setScreenStatus(String screenStatus) {
        this.screenStatus = screenStatus;
    }

    public String getRingMode() {
        return ringMode;
    }

    public void setRingMode(String ringMode) {
        this.ringMode = ringMode;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    @Override
    public String toString() {
        return "NotificationMessage{" +
                "id=" + id +
                ", postTime='" + postTime + '\'' +
                ", systemTime='" + systemTime + '\'' +
                ", appName='" + appName + '\'' +
                ", appPkg='" + appPkg + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", priority=" + priority +
                ", batteryLevel=" + batteryLevel +
                ", isCharging=" + isCharging +
                ", screenStatus='" + screenStatus + '\'' +
                ", ringMode='" + ringMode + '\'' +
                ", location='" + location + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", connectionType='" + connectionType + '\'' +
                ", operation='" + operation + '\'' +
                '}';
    }
}

package com.notification.teller;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.LocaleList;
import android.os.PowerManager;
import android.provider.Settings;
import android.support.v4.content.PermissionChecker;

import java.util.ArrayList;
import java.util.List;

public class AppUtils {

    public static String getAppName(Context context, String packageName) {
        final PackageManager pm = context.getApplicationContext().getPackageManager();
        ApplicationInfo ai;
        try {
            ai = pm.getApplicationInfo(packageName, 0);
        } catch (final PackageManager.NameNotFoundException e) {
            ai = null;
        }
        return (String) (ai != null ? pm.getApplicationLabel(ai) : packageName);
    }

    public static Drawable getAppIcon(Context context, String packageName) {
        PackageManager pm = context.getApplicationContext().getPackageManager();
        Drawable drawable = null;
        try {
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            if (ai != null) {
                drawable = pm.getApplicationIcon(ai);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return drawable;
    }

    public static String nullToEmptyString(CharSequence charsequence) {
        if (charsequence == null) {
            return "";
        } else {
            return charsequence.toString();
        }
    }

    public static boolean isNotificationAccessEnabled(Context context) {
        try {
            ContentResolver contentResolver = context.getContentResolver();
            String listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners");
            return !(listeners == null || !listeners.contains(BuildConfig.APPLICATION_ID + "/"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static String getScreenStatus(Context context) {

        boolean isScreenOn = false;

        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            try {
                if (Build.VERSION.SDK_INT >= 20) {
                    isScreenOn = pm.isInteractive();
                } else {
                    //noinspection deprecation
                    isScreenOn = pm.isScreenOn();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return isScreenOn ? "解锁" : "锁屏";
    }

    /**
     * 获取当前手机状态
     */
    public static String getRingMode(Context context) {

        String mode = "未知";

        // 获取手机情景模式
        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        int ringerMode = audioManager.getRingerMode();
        switch (ringerMode) {
            case AudioManager.RINGER_MODE_NORMAL:
                mode = "响铃";
                break;
            case AudioManager.RINGER_MODE_SILENT:
                mode = "静音";
                break;
            case AudioManager.RINGER_MODE_VIBRATE:
                // 震动模式
                mode = "震动";
                break;
            default:
                break;
        }

        return mode;
    }

    public static String getLocale(Context context) {
        if (Build.VERSION.SDK_INT >= 24) {
            LocaleList localeList = context.getResources().getConfiguration().getLocales();
            return localeList.toString();
        } else {
            //noinspection deprecation
            return context.getResources().getConfiguration().locale.toString();
        }
    }

    public static boolean hasPermission(Context context, String permission) {
        return PermissionChecker.checkSelfPermission(context, permission) == PermissionChecker.PERMISSION_GRANTED;
    }

    public static String[] getAllInstalledApps(Context context) {
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        ArrayList<String> list = new ArrayList<>();
        for (ApplicationInfo packageInfo : packages) {
            list.add(packageInfo.packageName);
        }
        return list.toArray(new String[0]);
    }

    public static int getBatteryLevel(Context context) {
        if (Build.VERSION.SDK_INT >= 21) {
            BatteryManager bm = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                try {
                    return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return -1;
    }

    public static String getBatteryStatus(Context context) {
        if (Build.VERSION.SDK_INT < 26) {
            return "不支持";
        }
        try {
            BatteryManager bm = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                int status = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS);
                switch (status) {
                    case BatteryManager.BATTERY_STATUS_CHARGING:
                        return "充电";
                    case BatteryManager.BATTERY_STATUS_DISCHARGING:
                        return "放电";
                    case BatteryManager.BATTERY_STATUS_FULL:
                        return "满电";
                    case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                        return "未充电";
                    case BatteryManager.BATTERY_STATUS_UNKNOWN:
                        return "未知";
                    default:
                        return "" + status;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "未定义";
    }

    public static int isCharging(Context context) {
        if (Build.VERSION.SDK_INT < 26) {
            return 0;
        }
        try {
            BatteryManager bm = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                int status = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS);

                if (status == BatteryManager.BATTERY_STATUS_CHARGING) {
                    return 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            try {
                NetworkInfo activeNetworkInfo = cm.getActiveNetworkInfo();
                return activeNetworkInfo != null && activeNetworkInfo.isConnected();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static String getConnectivityType(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                if (networkInfo != null) {
                    int type = networkInfo.getType();
                    switch (type) {
                        case ConnectivityManager.TYPE_MOBILE:
                            return "mobile";
                        case ConnectivityManager.TYPE_WIFI:
                            return "wifi";
                        default:
                            return "" + type;
                    }
                } else {
                    return "无";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "未定义";
    }

}
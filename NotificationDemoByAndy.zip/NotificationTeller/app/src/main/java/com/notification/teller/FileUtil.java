package com.notification.teller;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.v4.content.FileProvider;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import org.litepal.LitePal;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class FileUtil {

    private static String TAG = "LogToFile";
    private static String logPath = "/mnt/sdcard";//log日志存放路径
    private static String fileName = "Notif-Tracking.txt";//log日志名
    private static Gson gson = new GsonBuilder().setPrettyPrinting().create();


    /**
     * 将log信息写入文件中
     */
    public static void export(Context context) {

        if (null == logPath) {
            Log.e(TAG, "logPath == null ，未初始化LogToFile");
            return;
        }

        //如果父路径不存在
        File folder = new File(logPath);
        if (!folder.exists()) {
            folder.mkdirs();//创建父路径
        }

        File file = new File(logPath, fileName);
        if (file.exists()) {
            file.delete();
        }

        FileOutputStream outputStream = null;//FileOutputStream会自动调用底层的close()方法，不用关闭
        try {

            outputStream = new FileOutputStream(file, true);//这里的第二个参数代表追加还是覆盖，true为追加，flase为覆盖

            Map<String, Object> mainMap = new LinkedHashMap<>();

            List<Map<String, Object>> post = new ArrayList<>();
            List<Map<String, Object>> remove = new ArrayList<>();


            List<NotificationMessage> operation1 = LitePal.where("operation=?", "接收").find(NotificationMessage.class);
            for (NotificationMessage nm : operation1) {

                Map<String, Object> map = new LinkedHashMap<>();
                map.put("when1", nm.getPostTime());
                map.put("app", nm.getAppName());
                map.put("title", nm.getTitle());
                map.put("priority", nm.getPriority());
                map.put("battery", nm.getBatteryLevel());
                map.put("charging", nm.isCharging());
                map.put("screen", nm.getScreenStatus());
                map.put("ringermode", nm.getRingMode());
                map.put("location", nm.getLocation());
                map.put("latitude", nm.getLatitude());
                map.put("longitude", nm.getLongitude());
                map.put("wifi", nm.getConnectionType());
                post.add(map);
            }

            List<NotificationMessage> operation2 = LitePal.where("operation=?", "移除").find(NotificationMessage.class);
            for (NotificationMessage nm : operation2) {

                Map<String, Object> map = new LinkedHashMap<>();
                map.put("when1", nm.getPostTime());
                map.put("app", nm.getAppName());
                map.put("title", nm.getTitle());
                map.put("when2", nm.getSystemTime());
                remove.add(map);
            }

            List<SurveyInfo> label = LitePal.findAll(SurveyInfo.class);

            mainMap.put("posted", post);
            mainMap.put("removed", remove);
            mainMap.put("label", label);

            String json = gson.toJson(mainMap);

            System.out.println(json);

            outputStream.write(json.getBytes());
            outputStream.flush();

            // Open the share dialog
            Intent sharingIntent = new Intent(Intent.ACTION_SEND);
            // Get the content provider URI
            Uri fileUri = null;
            if (Build.VERSION.SDK_INT >= 24) {
                fileUri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileProvider", file);
                context.grantUriPermission(context.getPackageName(), fileUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                sharingIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            } else {
                fileUri = Uri.fromFile(file);
            }


            sharingIntent.setType("text/plain");
            sharingIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
            context.startActivity(Intent.createChooser(sharingIntent, "导出数据"));

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.close();//关闭缓冲流
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private static String jsonFormatter(String uglyJSONString) {

        JsonParser jp = new JsonParser();
        JsonElement je = jp.parse(uglyJSONString);
        return gson.toJson(je);
    }


}

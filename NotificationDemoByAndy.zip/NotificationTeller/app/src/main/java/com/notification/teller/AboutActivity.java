package com.notification.teller;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class AboutActivity extends BaseActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        initView();

        webView.loadUrl("file:///android_asset/help.html");
    }

    private void initView() {
        setTitle("使用说明");
        webView = (WebView) findViewById(R.id.wv);
    }

    private void initWebView() {
        WebSettings webSettings = webView.getSettings();
        // 支持javascript
        webSettings.setJavaScriptEnabled(true);

        // 支持使用localStorage
        webSettings.setDomStorageEnabled(true);

        // 支持数据库
        webSettings.setDatabaseEnabled(true);

        // 支持缓存
        webSettings.setAppCacheEnabled(true);
        String appCaceDir = this.getApplicationContext().getDir("cache", Context.MODE_PRIVATE).getPath();
        webSettings.setAppCachePath(appCaceDir);

        // 设置可以支持缩放
        webSettings.setUseWideViewPort(true);

        // 扩大比例的缩放
        webSettings.setSupportZoom(true);

        webSettings.setBuiltInZoomControls(true);

        // 隐藏缩放按钮
        webSettings.setDisplayZoomControls(false);

        // 自适应屏幕
        webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webSettings.setLoadWithOverviewMode(true);

        // 隐藏滚动条
        webView.setHorizontalScrollBarEnabled(false);
        webView.setVerticalScrollBarEnabled(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {

            }
        });

        MyWebViewClient client = new MyWebViewClient();
        webView.setWebViewClient(client);

    }

    public class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
            //重点：看下面
            WebView.HitTestResult hitTestResult = view.getHitTestResult();
            //hitTestResult==null解决重定向问题

            if (!TextUtils.isEmpty(url) && hitTestResult == null) {

                view.loadUrl(url);

                return true;

            }
            return super.shouldOverrideUrlLoading(view, url);

        }

        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            view.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
            //重点：看下面
            WebView.HitTestResult hitTestResult = view.getHitTestResult();
            //hitTestResult==null解决重定向问题
            if (!TextUtils.isEmpty(request.getUrl().toString()) && hitTestResult == null) {
                view.loadUrl(request.getUrl().toString());
                return true;

            }
            return super.shouldOverrideUrlLoading(view, request);
        }
    }
}
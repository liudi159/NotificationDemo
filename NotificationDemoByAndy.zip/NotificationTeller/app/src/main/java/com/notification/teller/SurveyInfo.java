package com.notification.teller;

import org.litepal.crud.LitePalSupport;

public class SurveyInfo extends LitePalSupport {

    private transient int id;
    private transient int pid;

    private String when1;
    private String app;
    private String title;
    private int importance;
    private String reasons1;
    private int interruptiblity;
    private String perception;
    private String available;
    private String device;
    private String action;
    private String reasons2;
    private String activity;
    private int task;
    private String where;
    private String people;
    private String who;
    private int Valence;
    private int TenseCalm;
    private int TiredAwake;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getWhen1() {
        return when1;
    }

    public void setWhen1(String when1) {
        this.when1 = when1;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImportance() {
        return importance;
    }

    public void setImportance(int importance) {
        this.importance = importance;
    }

    public String getReasons1() {
        return reasons1;
    }

    public void setReasons1(String reasons1) {
        this.reasons1 = reasons1;
    }

    public int getInterruptiblity() {
        return interruptiblity;
    }

    public void setInterruptiblity(int interruptiblity) {
        this.interruptiblity = interruptiblity;
    }

    public String getPerception() {
        return perception;
    }

    public void setPerception(String perception) {
        this.perception = perception;
    }

    public String getAvailable() {
        return available;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getReasons2() {
        return reasons2;
    }

    public void setReasons2(String reasons2) {
        this.reasons2 = reasons2;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public int getTask() {
        return task;
    }

    public void setTask(int task) {
        this.task = task;
    }

    public String getWhere() {
        return where;
    }

    public void setWhere(String where) {
        this.where = where;
    }

    public String getPeople() {
        return people;
    }

    public void setPeople(String people) {
        this.people = people;
    }

    public String getWho() {
        return who;
    }

    public void setWho(String who) {
        this.who = who;
    }


    public int getValence() {
        return Valence;
    }

    public void setValence(int valence) {
        Valence = valence;
    }

    public int getTenseCalm() {
        return TenseCalm;
    }

    public void setTenseCalm(int tenseCalm) {
        TenseCalm = tenseCalm;
    }

    public int getTiredAwake() {
        return TiredAwake;
    }

    public void setTiredAwake(int tiredAwake) {
        TiredAwake = tiredAwake;
    }
}

package com.notification.teller;

import android.database.Cursor;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;

import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.List;

public class BarChartActivity extends BaseActivity {


    private BarChart chart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar_chart);
        initView();

        Cursor cursor = LitePal.findBySQL("SELECT COUNT(*) AS count,appname FROM notificationmessage GROUP BY apppkg ORDER BY count desc LIMIT 5");

        List<String> xAxisValue = new ArrayList<>();
        List<BarEntry> barEntries = new ArrayList<>();

        int i = 0;
        while (cursor.moveToNext()) {

            xAxisValue.add(cursor.getString(cursor.getColumnIndex("appname")));
            BarEntry barEntry = new BarEntry(i, cursor.getLong(cursor.getColumnIndex("count")));
            barEntries.add(barEntry);
            i++;
        }

        chart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(xAxisValue));


        BarDataSet set1 = new BarDataSet(barEntries, "通知数量 Top 5");
        //设置每个树状图的颜色，一共有两个方法setColors和setColor
        set1.setColor(getResources().getColor(android.R.color.holo_orange_dark));


        ArrayList<IBarDataSet> barDataSets = new ArrayList<>();
        barDataSets.add(set1);


        BarData barData = new BarData(barDataSets);
        //设置树状图的宽度
        barData.setBarWidth(0.5f);
        //设置树状图上的字的字号
        barData.setValueTextSize(10);


        chart.setData(barData);
    }

    private void initView() {
        chart = (BarChart) findViewById(R.id.chart);

        //描述
        chart.setDescription(null);
        //是否能否拖拽
        chart.setDragEnabled(false);
        //是否能够缩放
        chart.setPinchZoom(false);
        //允许X轴缩放
        chart.setScaleXEnabled(false);
        //允许Y轴缩放
        chart.setScaleYEnabled(false);


        //取到X轴的操作对象
        XAxis xAxis = chart.getXAxis();
        //是否显示X轴的线(与X轴垂直的线),默认为true
        xAxis.setDrawGridLines(false);
        //设置XAxis坐标的字在哪里显示 XAxisPosition{ TOP, BOTTOM, BOTH_SIDED, TOP_INSIDE, BOTTOM_INSIDE}
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        //设置X轴的值的间隔，具体不同看下面的图
        xAxis.setGranularity(1f);

        //得到左侧Y轴的实例
        YAxis leftYaxis = chart.getAxisLeft();
        leftYaxis.setAxisMinimum(0);
        //设置网格线
        leftYaxis.setDrawGridLines(true);
        //设置将在全范围的百分比顶轴的空间。默认10F.设置在图表上最高处的值相比轴上最高值的顶端空间（总轴范围的百分比）最大值和最高值的百分比 设置为100，则最高值为最大值的1倍
        leftYaxis.setSpaceTop(15f);

        chart.getAxisRight().setEnabled(false);
    }
}
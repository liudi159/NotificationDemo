package com.notification.teller;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.List;

public class MessageActivity extends BaseActivity {

    private TextView tv_count;
    private ListView lv;
    private NotificationBroadcastReceiver broadcastReceiver;
    private List<NotificationMessage> data = new ArrayList<>();
    private MessageAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        initView();

        refresh();
        registerBroadcastReceiver();

    }

    private void initView() {

        setTitle("管理消息通知");
        tv_count = (TextView) findViewById(R.id.tv_count);
        lv = (ListView) findViewById(R.id.lv);
        adapter = new MessageAdapter(data);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                NotificationMessage nm = data.get(position);

                SurveyInfo surveyInfo = LitePal.where("pid=?", String.valueOf(nm.getId())).findFirst(SurveyInfo.class);
                if (surveyInfo == null) {
                    Intent intent = new Intent(MessageActivity.this, SurveyActivity.class);
                    intent.putExtra("msg", nm);
                    startActivity(intent);
                } else {

                    Toast.makeText(MessageActivity.this, "该消息通知已经填过问卷", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
    }

    private void registerBroadcastReceiver() {
        broadcastReceiver = new NotificationBroadcastReceiver();
        IntentFilter notificationIntentFilter = new IntentFilter("action.notification");
        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, notificationIntentFilter);
    }


    private void refresh() {

        data.clear();
        List<NotificationMessage> all = LitePal.where("operation=?", "接收").order("postTime desc").find(NotificationMessage.class);
        if (all != null && !all.isEmpty()) {
            data.addAll(all);
        }
        adapter.notifyDataSetChanged();
        tv_count.setText("共" + data.size() + "条消息通知");
    }

    class NotificationBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            refresh();

        }
    }


}
package com.notification.teller;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import org.litepal.LitePal;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class LineChartActivity extends BaseActivity implements View.OnClickListener {

    private Button btn_date;
    private LineChart chart;
    private Calendar calendar;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");


    private LineChart mChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_line_chart);
        initView();

        calendar = Calendar.getInstance();
        btn_date.setText(sdf.format(calendar.getTime()));

        updateChat();
    }

    private void initView() {
        btn_date = (Button) findViewById(R.id.btn_date);
        chart = (LineChart) findViewById(R.id.chart);

        btn_date.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_date:

                DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                                calendar.set(Calendar.YEAR, year);
                                calendar.set(Calendar.MONTH, month);
                                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                                btn_date.setText(sdf.format(calendar.getTime()));

                                updateChat();

                            }
                        },
                        calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();

                break;
        }
    }

    private void initChart() {
        //图表初始化
        mChart = (LineChart) findViewById(R.id.chart);
        mChart.clear();
        // enable description text
        mChart.getDescription().setEnabled(false);
        // enable touch gestures
        mChart.setTouchEnabled(true);
        mChart.setPinchZoom(false);
        mChart.setScaleXEnabled(false);
        mChart.setScaleYEnabled(false);

        // get the legend (only possible after setting data)
        Legend l = mChart.getLegend();
        l.setEnabled(false);

        XAxis xl = mChart.getXAxis();
        xl.setAvoidFirstLastClipping(true);
        xl.setDrawGridLines(true);
        xl.setLabelCount(24, true);
        xl.setTextColor(Color.parseColor("#a7a5a6"));
        xl.setGridColor(Color.parseColor("#a7a5a6"));
        xl.setPosition(XAxis.XAxisPosition.BOTTOM);
        xl.setValueFormatter(new IAxisValueFormatter() {


            @Override
            public String getFormattedValue(float value, AxisBase axis) {

                int intValue = (int) value;
                return String.valueOf(intValue);
            }
        });

        YAxis leftAxis = mChart.getAxisLeft();
        leftAxis.setDrawGridLines(true);
        leftAxis.setTextColor(Color.parseColor("#ffffbb33"));
        leftAxis.setGridColor(Color.parseColor("#a7a5a6"));
        leftAxis.setAxisMinimum(0);

        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setEnabled(false);

    }

    private void updateChat() {

        initChart();
        List<Integer> counts = new ArrayList<>();

        for (int i = 0; i < 24; i++) {

            String hour = formatNum(i);

            String start = btn_date.getText().toString() + " " + hour + ":00:00";
            String end = btn_date.getText().toString() + " " + hour + ":59:59";

            List<NotificationMessage> all = LitePal.where("operation=? and postTime>=? and postTime<=?", "接收", start, end).find(NotificationMessage.class);

            counts.add(all.size());

        }


        LineData data = new LineData();

        ArrayList<Entry> yVals = new ArrayList<Entry>();

        for (int i = 0; i < counts.size(); i++) {
            yVals.add(new Entry(i, counts.get(i)));
        }


        LineDataSet set = new LineDataSet(yVals, "消息通知数量");
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setColor(Color.parseColor("#ffffbb33"));
        set.setDrawCircles(true);
        set.setDrawValues(true);
        set.setHighLightColor(Color.parseColor("#ffff8800"));
        set.setDrawCircleHole(true);
        set.setHighlightEnabled(true);
        set.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {

                int intValue = (int) value;

                return String.valueOf(intValue);
            }
        });

        data.addDataSet(set);
        data.notifyDataChanged();
        mChart.setData(data);
        mChart.notifyDataSetChanged();
        mChart.invalidate();


    }

    private String formatNum(int num) {

        if (num < 10) {
            return "0" + num;
        } else {
            return String.valueOf(num);
        }
    }
}
package com.notification.teller;

import android.Manifest;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Process;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.permissionx.guolindev.PermissionX;
import com.permissionx.guolindev.callback.RequestCallback;

import java.util.List;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    private final String TAG = MainActivity.class.getName();
    private TextView btn_permission;
    private TextView btn_manager;
    private TextView btn_visualization1;
    private TextView btn_export;
    private TextView btn_about;
    private TextView btn_visualization2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();

        PermissionX.init(this)
                .permissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.READ_PHONE_STATE).request(new RequestCallback() {
            @Override
            public void onResult(boolean allGranted, List<String> grantedList, List<String> deniedList) {

            }
        });

    }

    /**
     * 判断NotificationListenerServices是否被授予Notification Access权限
     *
     * @return
     */
    private boolean isNotificationServiceEnabled() {
        return NotificationManagerCompat.getEnabledListenerPackages(this).contains(getPackageName());
    }

    /**
     * 确保NotificationListenerService在后台运行，所以通过判断服务是否在运行中的服务中来进行触发系统rebind操作
     */
    private void ensureServiceIsRunning() {
        ComponentName serviceComponent = new ComponentName(this, NotificationMonitorService.class);
        Log.d(TAG, "确保服务NotificationListenerExampleService正在运行");
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        boolean isRunning = false;
        List<ActivityManager.RunningServiceInfo> runningServiceInfos = manager.getRunningServices(Integer.MAX_VALUE);
        if (runningServiceInfos == null) {
            Log.w(TAG, "运行中的服务为空");
            return;
        }

        for (ActivityManager.RunningServiceInfo serviceInfo : runningServiceInfos) {
            if (serviceInfo.service.equals(serviceComponent)) {
                Log.w(TAG, "ensureServiceRunning service - pid: " + serviceInfo.pid
                        + ",currentPID: " + Process.myPid()
                        + ", clientPackage: " + serviceInfo.clientPackage
                        + ", clientCount: " + serviceInfo.clientCount
                        + ", clientLabel: " + ((serviceInfo.clientLabel == 0) ? "0" : "(" + getResources().getString(serviceInfo.clientLabel) + ")"));
                if (serviceInfo.pid == Process.myPid()) {
                    isRunning = true;
                }
            }
        }

        if (isRunning) {
            Log.d(TAG, "ensureServiceIsRunning: 监听服务正在运行");
            return;
        }

        Log.d(TAG, "ensureServiceIsRunning: 服务没有运行，重启中...");
        toggleNotificationListenerService();
    }

    /**
     * 不调用下面的函数，第一次安装使用app能够正常读取通知栏的通知。但是把app进城杀掉重启发现不能拦截到通知栏消息，
     * 这是因为监听器服务没有开启，更深层的原因是没有bindService。解决方法是把NotificationListenerService的实
     * 现类disable后再enable，这样可以触发系统的rebind操作。
     * <p>
     */
    private void toggleNotificationListenerService() {
        PackageManager pm = getPackageManager();
        pm.setComponentEnabledSetting(new ComponentName(this, NotificationMonitorService.class),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        pm.setComponentEnabledSetting(new ComponentName(this, NotificationMonitorService.class),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
    }

    private AlertDialog buildNotificationServiceAlertDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle(R.string.app_name);
        alertDialogBuilder.setMessage(R.string.start_notification_monitor);
        alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivityForResult(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"), 1024);
            }
        });
        alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "不授予通知读取权限Monitor将无法运行！", Toast.LENGTH_SHORT)
                        .show();
            }
        });
        return alertDialogBuilder.create();
    }


    @Override
    public void onBackPressed() {
        moveTaskToBack(false);
//        super.onBackPressed(); //注释super,拦截返回键功能
    }

    @Override
    protected void onResume() {
        super.onResume();
        ensureServiceIsRunning();
    }


    private void initView() {
        btn_permission = (TextView) findViewById(R.id.btn_permission);
        btn_manager = (TextView) findViewById(R.id.btn_manager);
        btn_visualization1 = (TextView) findViewById(R.id.btn_visualization1);
        btn_export = (TextView) findViewById(R.id.btn_export);
        btn_about = (TextView) findViewById(R.id.btn_about);

        btn_permission.setOnClickListener(this);
        btn_manager.setOnClickListener(this);
        btn_visualization1.setOnClickListener(this);
        btn_export.setOnClickListener(this);
        btn_about.setOnClickListener(this);
        btn_visualization2 = (TextView) findViewById(R.id.btn_visualization2);
        btn_visualization2.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_permission:

                if (isNotificationServiceEnabled()) {

                    Toast.makeText(this, "已获取通知权限", Toast.LENGTH_SHORT).show();

                } else {

                    AlertDialog enableNotificationListenerDialog = buildNotificationServiceAlertDialog();
                    enableNotificationListenerDialog.show();
                }

                break;
            case R.id.btn_manager:

                startActivity(new Intent(this, MessageActivity.class));

                break;
            case R.id.btn_visualization1:

                startActivity(new Intent(this, LineChartActivity.class));

                break;

            case R.id.btn_visualization2:

                startActivity(new Intent(this, BarChartActivity.class));

                break;

            case R.id.btn_export:

                FileUtil.export(this);

                break;
            case R.id.btn_about:

                startActivity(new Intent(this, AboutActivity.class));

                break;

        }
    }

}

package com.notification.teller;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.TextView;

public class SurveyActivity extends BaseActivity implements View.OnClickListener {

    private TextView tv_from;
    private TextView tv_time;
    private TextView tv_title;
    private Button btn_next;
    private RatingBar rb_important;
    private RatingBar rb_interrupt;
    private RadioButton rb_notice1;
    private RadioButton rb_notice2;
    private RadioButton rb_free1;
    private RadioButton rb_free2;
    private RadioButton rb_doing1;
    private RadioButton rb_doing2;
    private RadioButton rb_doing3;
    private RadioButton rb_doing4;
    private RadioButton rb_doing5;
    private RadioButton rb_doing6;
    private RadioButton rb_doing7;
    private RadioButton rb_doing8;
    private RadioButton rb_where1;
    private RadioButton rb_where2;
    private RadioButton rb_where3;
    private RadioButton rb_where4;
    private RadioButton rb_where5;
    private RadioButton rb_where6;
    private RadioButton rb_people1;
    private RadioButton rb_people2;
    private RadioButton rb_people3;
    private RadioButton rb_people4;
    private RadioButton rb_people5;
    private RadioButton rb_deal1;
    private RadioButton rb_deal2;
    private RadioButton rb_deal3;
    private RadioButton rb_deal4;
    private EditText et_why;
    private FlowRadioGroup frg_notice;
    private FlowRadioGroup frg_free;
    private FlowRadioGroup frg_doing;
    private FlowRadioGroup frg_where;
    private FlowRadioGroup frg_people;
    private FlowRadioGroup frg_deal;
    private EditText et_why_important;
    private RadioButton rb_notice3;
    private RadioButton rb_device1;
    private RadioButton rb_device2;
    private RadioButton rb_device3;
    private RadioButton rb_device4;
    private RadioButton rb_device5;
    private FlowRadioGroup frg_device;
    private RadioButton rb_doing9;
    private RadioButton rb_doing10;
    private RadioButton rb_doing11;
    private RatingBar rb_focus;
    private RadioButton rb_where7;
    private RadioButton rb_amount1;
    private RadioButton rb_amount2;
    private RadioButton rb_amount3;
    private RadioButton rb_amount4;
    private RadioButton rb_amount5;
    private RadioButton rb_amount6;
    private FlowRadioGroup frg_amount;
    private RadioButton rb_people6;
    private RadioButton rb_people7;
    private RatingBar rb_mood1;
    private RatingBar rb_mood2;
    private RatingBar rb_mood3;
    private NotificationMessage nm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);
        initView();

        nm = (NotificationMessage) getIntent().getSerializableExtra("msg");
        tv_from.setText("消息来源：" +nm.getAppName());
        tv_title.setText("消息标题：" + nm.getTitle());
        tv_time.setText(nm.getPostTime());

    }

    private void initView() {
        tv_from = (TextView) findViewById(R.id.tv_from);
        tv_time = (TextView) findViewById(R.id.tv_time);
        tv_title = (TextView) findViewById(R.id.tv_title);
        btn_next = (Button) findViewById(R.id.btn_next);
        btn_next.setOnClickListener(this);
        rb_important = (RatingBar) findViewById(R.id.rb_important);
        rb_interrupt = (RatingBar) findViewById(R.id.rb_interrupt);
        rb_notice1 = (RadioButton) findViewById(R.id.rb_notice1);
        rb_notice2 = (RadioButton) findViewById(R.id.rb_notice2);
        rb_free1 = (RadioButton) findViewById(R.id.rb_free1);
        rb_free2 = (RadioButton) findViewById(R.id.rb_free2);
        rb_doing1 = (RadioButton) findViewById(R.id.rb_doing1);
        rb_doing2 = (RadioButton) findViewById(R.id.rb_doing2);
        rb_doing3 = (RadioButton) findViewById(R.id.rb_doing3);
        rb_doing4 = (RadioButton) findViewById(R.id.rb_doing4);
        rb_doing5 = (RadioButton) findViewById(R.id.rb_doing5);
        rb_doing6 = (RadioButton) findViewById(R.id.rb_doing6);
        rb_doing7 = (RadioButton) findViewById(R.id.rb_doing7);
        rb_doing8 = (RadioButton) findViewById(R.id.rb_doing8);
        rb_where1 = (RadioButton) findViewById(R.id.rb_where1);
        rb_where2 = (RadioButton) findViewById(R.id.rb_where2);
        rb_where3 = (RadioButton) findViewById(R.id.rb_where3);
        rb_where4 = (RadioButton) findViewById(R.id.rb_where4);
        rb_where5 = (RadioButton) findViewById(R.id.rb_where5);
        rb_where6 = (RadioButton) findViewById(R.id.rb_where6);
        rb_people1 = (RadioButton) findViewById(R.id.rb_people1);
        rb_people2 = (RadioButton) findViewById(R.id.rb_people2);
        rb_people3 = (RadioButton) findViewById(R.id.rb_people3);
        rb_people4 = (RadioButton) findViewById(R.id.rb_people4);
        rb_people5 = (RadioButton) findViewById(R.id.rb_people5);
        rb_deal1 = (RadioButton) findViewById(R.id.rb_deal1);
        rb_deal2 = (RadioButton) findViewById(R.id.rb_deal2);
        rb_deal3 = (RadioButton) findViewById(R.id.rb_deal3);
        rb_deal4 = (RadioButton) findViewById(R.id.rb_deal4);
        et_why = (EditText) findViewById(R.id.et_why);
        frg_notice = (FlowRadioGroup) findViewById(R.id.frg_notice);
        frg_free = (FlowRadioGroup) findViewById(R.id.frg_free);
        frg_doing = (FlowRadioGroup) findViewById(R.id.frg_doing);
        frg_where = (FlowRadioGroup) findViewById(R.id.frg_where);
        frg_people = (FlowRadioGroup) findViewById(R.id.frg_people);
        frg_deal = (FlowRadioGroup) findViewById(R.id.frg_deal);
        et_why_important = (EditText) findViewById(R.id.et_why_important);
        rb_notice3 = (RadioButton) findViewById(R.id.rb_notice3);
        rb_device1 = (RadioButton) findViewById(R.id.rb_device1);
        rb_device2 = (RadioButton) findViewById(R.id.rb_device2);
        rb_device3 = (RadioButton) findViewById(R.id.rb_device3);
        rb_device4 = (RadioButton) findViewById(R.id.rb_device4);
        rb_device5 = (RadioButton) findViewById(R.id.rb_device5);
        frg_device = (FlowRadioGroup) findViewById(R.id.frg_device);
        rb_doing9 = (RadioButton) findViewById(R.id.rb_doing9);
        rb_doing10 = (RadioButton) findViewById(R.id.rb_doing10);
        rb_doing11 = (RadioButton) findViewById(R.id.rb_doing11);
        rb_focus = (RatingBar) findViewById(R.id.rb_focus);
        rb_where7 = (RadioButton) findViewById(R.id.rb_where7);
        rb_amount1 = (RadioButton) findViewById(R.id.rb_amount1);
        rb_amount2 = (RadioButton) findViewById(R.id.rb_amount2);
        rb_amount3 = (RadioButton) findViewById(R.id.rb_amount3);
        rb_amount4 = (RadioButton) findViewById(R.id.rb_amount4);
        rb_amount5 = (RadioButton) findViewById(R.id.rb_amount5);
        rb_amount6 = (RadioButton) findViewById(R.id.rb_amount6);
        frg_amount = (FlowRadioGroup) findViewById(R.id.frg_amount);
        rb_people6 = (RadioButton) findViewById(R.id.rb_people6);
        rb_people7 = (RadioButton) findViewById(R.id.rb_people7);
        rb_mood1 = (RatingBar) findViewById(R.id.rb_mood1);
        rb_mood2 = (RatingBar) findViewById(R.id.rb_mood2);
        rb_mood3 = (RatingBar) findViewById(R.id.rb_mood3);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btn_next:

                save();

                break;
        }
    }

    private void save() {

        SurveyInfo surveyInfo = new SurveyInfo();
        surveyInfo.setPid(nm.getId());
        surveyInfo.setWhen1(nm.getPostTime());
        surveyInfo.setApp(nm.getAppName());
        surveyInfo.setTitle(nm.getTitle());
        surveyInfo.setImportance((int) rb_important.getRating());

        String why_important = et_why_important.getText().toString().trim();
        if (TextUtils.isEmpty(why_important)) {
            surveyInfo.setReasons1("null");
        } else {
            surveyInfo.setReasons1("why_important");
        }

        surveyInfo.setInterruptiblity((int) rb_interrupt.getRating());

        if (rb_notice1.isChecked()) {
            surveyInfo.setPerception("1");
        } else if (rb_notice2.isChecked()) {
            surveyInfo.setPerception("2");
        } else if (rb_notice3.isChecked()) {
            surveyInfo.setPerception("3");
        } else {
            surveyInfo.setPerception("null");
        }

        if (rb_free1.isChecked()) {
            surveyInfo.setAvailable("1");
        } else if (rb_free2.isChecked()) {
            surveyInfo.setAvailable("0");
        } else {
            surveyInfo.setAvailable("null");
        }

        if (rb_device1.isChecked()) {
            surveyInfo.setDevice("1");
        } else if (rb_device2.isChecked()) {
            surveyInfo.setDevice("2");
        } else if (rb_device3.isChecked()) {
            surveyInfo.setDevice("3");
        } else if (rb_device4.isChecked()) {
            surveyInfo.setDevice("4");
        } else if (rb_device5.isChecked()) {
            surveyInfo.setDevice("5");
        } else {
            surveyInfo.setDevice("null");
        }

        if (rb_deal1.isChecked()) {
            surveyInfo.setAction("1");
        } else if (rb_deal2.isChecked()) {
            surveyInfo.setAction("2");
        } else if (rb_deal3.isChecked()) {
            surveyInfo.setAction("3");
        } else if (rb_deal4.isChecked()) {
            surveyInfo.setAction("4");
        } else {
            surveyInfo.setAction("null");
        }


        String why = et_why.getText().toString().trim();
        if (TextUtils.isEmpty(why)) {
            surveyInfo.setReasons2("null");
        } else {
            surveyInfo.setReasons2(why);
        }


        if (rb_doing1.isChecked()) {
            surveyInfo.setActivity("1");
        } else if (rb_doing2.isChecked()) {
            surveyInfo.setActivity("2");
        } else if (rb_doing3.isChecked()) {
            surveyInfo.setActivity("3");
        } else if (rb_doing4.isChecked()) {
            surveyInfo.setActivity("4");
        } else if (rb_doing5.isChecked()) {
            surveyInfo.setActivity("5");
        } else if (rb_doing6.isChecked()) {
            surveyInfo.setActivity("6");
        } else if (rb_doing7.isChecked()) {
            surveyInfo.setActivity("7");
        } else if (rb_doing8.isChecked()) {
            surveyInfo.setActivity("8");
        } else if (rb_doing9.isChecked()) {
            surveyInfo.setActivity("9");
        } else if (rb_doing10.isChecked()) {
            surveyInfo.setActivity("10");
        } else if (rb_doing11.isChecked()) {
            surveyInfo.setActivity("11");
        } else {
            surveyInfo.setActivity("null");
        }

        surveyInfo.setTask((int) rb_focus.getRating());

        if (rb_where1.isChecked()) {
            surveyInfo.setWhere("1");
        } else if (rb_where2.isChecked()) {
            surveyInfo.setWhere("2");
        } else if (rb_where3.isChecked()) {
            surveyInfo.setWhere("3");
        } else if (rb_where4.isChecked()) {
            surveyInfo.setWhere("4");
        } else if (rb_where5.isChecked()) {
            surveyInfo.setWhere("5");
        } else if (rb_where6.isChecked()) {
            surveyInfo.setWhere("6");
        } else if (rb_where7.isChecked()) {
            surveyInfo.setWhere("7");
        } else {
            surveyInfo.setWhere("null");
        }

        if (rb_amount1.isChecked()) {
            surveyInfo.setPeople("1");
        } else if (rb_amount2.isChecked()) {
            surveyInfo.setPeople("2");
        } else if (rb_amount3.isChecked()) {
            surveyInfo.setPeople("3");
        } else if (rb_amount4.isChecked()) {
            surveyInfo.setPeople("4");
        } else if (rb_amount5.isChecked()) {
            surveyInfo.setPeople("5");
        } else if (rb_amount6.isChecked()) {
            surveyInfo.setPeople("6");
        } else {
            surveyInfo.setPeople("null");
        }

        if (rb_people1.isChecked()) {
            surveyInfo.setWho("1");
        } else if (rb_people2.isChecked()) {
            surveyInfo.setWho("2");
        } else if (rb_people3.isChecked()) {
            surveyInfo.setWho("3");
        } else if (rb_people4.isChecked()) {
            surveyInfo.setWho("4");
        } else if (rb_people5.isChecked()) {
            surveyInfo.setWho("5");
        } else if (rb_people6.isChecked()) {
            surveyInfo.setWho("6");
        } else if (rb_people7.isChecked()) {
            surveyInfo.setWho("7");
        } else {
            surveyInfo.setWho("null");
        }


        surveyInfo.setValence((int) rb_mood1.getRating());
        surveyInfo.setTenseCalm((int) rb_mood2.getRating());
        surveyInfo.setTiredAwake((int) rb_mood3.getRating());

        surveyInfo.save();

        rb_important.setRating(0);
        et_why_important.setText("");
        rb_interrupt.setRating(0);
        frg_notice.clearCheck();
        frg_free.clearCheck();
        frg_device.clearCheck();
        frg_deal.clearCheck();
        et_why.setText("");
        frg_doing.clearCheck();
        rb_focus.setRating(0);
        frg_where.clearCheck();
        frg_amount.clearCheck();
        frg_people.clearCheck();
        rb_mood1.setRating(0);
        rb_mood2.setRating(0);
        rb_mood3.setRating(0);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("提示")
                .setMessage("填写完成")
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();
                    }
                })
                .create();
        dialog.setCancelable(false);
        dialog.show();

    }
}

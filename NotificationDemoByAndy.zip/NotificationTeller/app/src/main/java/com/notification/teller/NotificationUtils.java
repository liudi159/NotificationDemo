package com.notification.teller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NotificationUtils {

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private static int index = 0;

    /**
     * 弹出通知提醒
     */
    public static void tapNotification(Context context) {

        String title = "标题" + index;
        String content = "定时通知" + index;

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("isClick", true);
        intent.putExtra("title", title);
        intent.putExtra("content", content);
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        index = index + 1;
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        String channelID = "1024";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelID);

//        sendBroadcast(context, title, content, "发送");

        builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)//设置通知标题
                .setContentText(title)//设置通知内容
                .setContentIntent(contentIntent)
                .setAutoCancel(true)//设为true，点击通知栏移除通知
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.mipmap.ic_launcher))//设置大图标
                .setNumber(index)//显示在右边的数字
                .setOngoing(false)//设置是否是正在进行中的通知，默认是false
                .setOnlyAlertOnce(false)//设置是否只通知一次
                .setTicker("通知测试")//提示
                .setWhen(System.currentTimeMillis())
                .setLocalOnly(true)//设置此通知是否仅与当前设备相关。如果设置为true，通知就不能桥接到其他设备上进行远程显示。
                .setShowWhen(true);
        if (index % 5 == 0) {
            builder.setSortKey("A");//设置针对一个包内的通知进行排序的键值
        } else if (index % 5 == 1) {
            builder.setSortKey("B");//设置针对一个包内的通知进行排序的键值
        } else if (index % 5 == 2) {
            builder.setSortKey("C");//设置针对一个包内的通知进行排序的键值
        } else if (index % 5 == 3) {
            builder.setSortKey("D");//设置针对一个包内的通知进行排序的键值
        } else if (index % 5 == 4) {
            builder.setSortKey("E");//设置针对一个包内的通知进行排序的键值
        }

        builder.setVisibility(Notification.VISIBILITY_PUBLIC);//悬挂通知（横幅）


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {//Android 8.0以上
            String channelName = "我是通知渠道";
            NotificationChannel channel = new NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_HIGH);
            channel.enableLights(true);//设置通知出现时的闪灯（如果 android 设备支持的话）
            channel.enableVibration(true);// 设置通知出现时的震动（如果 android 设备支持的话）
            channel.setDescription("AAAAAAAAAA");//设置渠道的描述信息
            //channel.setGroup("AAAA");
            channel.setImportance(NotificationManager.IMPORTANCE_HIGH);
            channel.setLightColor(Color.YELLOW);
            //channel.setLockscreenVisibility();
            channel.setName("wweqw");

            // 设置显示模式
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);

            notificationManager.createNotificationChannel(channel);
            //创建通知时指定channelID
            builder.setChannelId(channelID);
        }

        Notification notification = builder.build();
        //锁屏时显示通知
        builder.setPublicVersion(notification);

        notificationManager.notify(index, notification);
    }

    public static void sendBroadcast(Context context, String title, String content, String operation) {

        Intent localIntent = new Intent("action.notification");
        localIntent.putExtra("action", operation);
        localIntent.putExtra("title", title);
        localIntent.putExtra("content", content);
        localIntent.putExtra("package", context.getPackageName());
        localIntent.putExtra("datetime", sdf.format(new Date()));
        LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent);

    }
}

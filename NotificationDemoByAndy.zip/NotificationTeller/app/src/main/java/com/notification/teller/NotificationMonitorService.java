package com.notification.teller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NotificationMonitorService extends NotificationListenerService {

    private String TAG = "NotificationMonitorService";
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private AMapLocation mLocation;
    //声明AMapLocationClient类对象
    public AMapLocationClient mLocationClient = null;
    //声明定位回调监听器
    public AMapLocationListener mLocationListener = new AMapLocationListener() {
        @Override
        public void onLocationChanged(AMapLocation aMapLocation) {
            if (aMapLocation != null && aMapLocation.getErrorCode() == 0) {
                mLocation = aMapLocation;
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "开启服务：NotificationMonitorService");
        startForeground(1, getNotification());

        //初始化定位
        mLocationClient = new AMapLocationClient(getApplicationContext());
        //设置定位回调监听
        mLocationClient.setLocationListener(mLocationListener);
        //声明AMapLocationClientOption对象
        AMapLocationClientOption option = new AMapLocationClientOption();
        //设置定位模式为AMapLocationMode.Hight_Accuracy，高精度模式。
        option.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
        //获取一次定位结果：
        option.setOnceLocation(true);
        //设置是否返回地址信息（默认返回地址信息）
        option.setNeedAddress(true);
        mLocationClient.setLocationOption(option);
        mLocationClient.startLocation();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Log.d(TAG, "通知所属包名：" + sbn.getPackageName());

        sendBroadcast(sbn, "接收");
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        Log.d(TAG, "监听到包：" + sbn.getPackageName() + " 的通知被移除");

        sendBroadcast(sbn, "移除");
    }

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "监听服务被销毁");
        stopForeground(true);
        mLocationClient.stopLocation();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    private Notification getNotification() {

        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        String channelId = getPackageName();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(channelId,
                    getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.setShowBadge(true);
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            notificationChannel.setImportance(NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(notificationChannel);

            builder.setChannelId(channelId);
        }


        Notification notification = builder
                .setContentTitle("Notification Monitor Service")
                .setContentText("服务正在运行...")
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                .setContentIntent(pendingIntent)
                .build();

        return notification;
    }

    @Override
    public void onListenerDisconnected() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            requestRebind(new ComponentName(this, NotificationMonitorService.class));
        }
    }

    private void sendBroadcast(StatusBarNotification sbn, String operation) {

        Notification notification = sbn.getNotification();
        if (notification == null) {
            return;
        }

        if ((notification.flags | Notification.FLAG_ONGOING_EVENT) == notification.flags) {
            // notification is an ongoing event

            return;
        }

        if (sbn.isOngoing()) {

            return;
        }

        // 当 API > 18 时，使用 extras 获取通知的详细信息
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Bundle extras = notification.extras;
            if (extras != null) {
                // 获取通知标题
                String title = extras.getString(Notification.EXTRA_TITLE, "");
                Log.d(TAG, "通知的标题为：" + title);
                // 获取通知内容
                String content = extras.getString(Notification.EXTRA_TEXT, "");
                Log.d(TAG, "通知的内容为：" + content);

                String systemTime = sdf.format(new Date());
                String appPkg = sbn.getPackageName();
                int priority = notification.priority;
                String postTime = sdf.format(new Date(sbn.getPostTime()));
                String appName = AppUtils.getAppName(this, appPkg);

                if ("com.tencent.qqpimsecure".equalsIgnoreCase(appPkg)) {

                    return;
                }

                if ("健康使用手机".equalsIgnoreCase(appName) || "Android 系统".equalsIgnoreCase(appName) || "系统用户界面".equalsIgnoreCase(appName)) {
                    return;
                }

                NotificationMessage nm = new NotificationMessage();
                nm.setPostTime(postTime);
                nm.setSystemTime(systemTime);
                nm.setAppName(appName);
                nm.setAppPkg(appPkg);
                nm.setTitle(title);
                nm.setContent(content);
                nm.setPriority(priority);
                nm.setBatteryLevel(AppUtils.getBatteryLevel(this));
                nm.setCharging(AppUtils.isCharging(this));
                nm.setScreenStatus(AppUtils.getScreenStatus(this));
                nm.setRingMode(AppUtils.getRingMode(this));
                if (mLocation != null) {
                    nm.setLocation(mLocation.getAddress());
                    nm.setLongitude(mLocation.getLongitude());
                    nm.setLatitude(mLocation.getLatitude());
                }
                nm.setConnectionType(AppUtils.getConnectivityType(this));
                nm.setOperation(operation);

                nm.save();
                Intent localIntent = new Intent("action.notification");
                LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);

            }
        }
    }
}

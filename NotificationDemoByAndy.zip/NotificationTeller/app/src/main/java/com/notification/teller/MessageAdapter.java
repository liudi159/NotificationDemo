package com.notification.teller;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MessageAdapter extends BaseAdapter {

    private List<NotificationMessage> data;

    public MessageAdapter(List<NotificationMessage> data) {

        this.data = data;
    }

    @Override
    public int getCount() {
        return data == null ? 0 : data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if (convertView == null) {
            convertView = View.inflate(parent.getContext(), R.layout.item_lv_msg, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        NotificationMessage item = data.get(position);
        Drawable drawable = AppUtils.getAppIcon(parent.getContext(), item.getAppPkg());
        if (drawable == null) {
            holder.iv_app.setImageResource(0);
        } else {
            holder.iv_app.setImageDrawable(drawable);
        }

        holder.tv_app.setText(item.getAppName());
        holder.tv_title.setText(item.getTitle());
        holder.tv_time.setText(item.getPostTime());

        return convertView;
    }

    public static
    class ViewHolder {
        public View rootView;
        public ImageView iv_app;
        public TextView tv_app;
        public TextView tv_title;
        public TextView tv_time;

        public ViewHolder(View rootView) {
            this.rootView = rootView;
            this.iv_app = (ImageView) rootView.findViewById(R.id.iv_app);
            this.tv_app = (TextView) rootView.findViewById(R.id.tv_app);
            this.tv_title = (TextView) rootView.findViewById(R.id.tv_title);
            this.tv_time = (TextView) rootView.findViewById(R.id.tv_time);
        }

    }
}
